//: Playground - noun: a place where people can play

import UIKit

var str = "Numerical Methods"

//: Bisection Method

func bisection (x: Double) -> Double {
    
    var lower = 1.0 // sets the lower bound to 1
    var upper = x   // sets the upper bound to x
    var m = (lower+upper)/2  // Finds the middle value m
    let epsilon = 1e-10     // Defines accuracy epsilon
    
    while (fabs(m * m - x) > epsilon){  // check if the operation has reached the desired accuracy
        
        m = ( lower + upper ) / 2
        if m * m > x {          // if not reached desired accuracy this block finds the middle of the new interval and checks which interval to use
            upper = m
        } else {
            lower = m
        }
    }
    
    return m
    
}

let bis = bisection(x: 2.5)  // Bisection function call



//: Heron Function to find Square root of a using f(x) = x^2 - a

func Heron(x:Double) -> Double{
    
    var xOld = 0.0
    var xNew = (x + 1.0) / 2.0
    let epsilon = 1e-10
    
    while (fabs(xNew-xOld) > epsilon){
        
        xOld = xNew
        xNew = (xOld + x / xOld) / 2
        
    }
    return xNew
    
    
}

let her = Heron(x: 2.5)


//: Harmonic Oscillators

//For this example, you’ll work with a mass attached to a spring. To make things easier, you’ll ignore damping and gravity, so the only force acting on the mass is the spring force that tries to pull the mass back to an offset position of zero.

// Q.  We have a mass of 2kg attached to a spring with a spring constant k=196N/m. At the time t=0 the spring has a displacement of 0.1m. To calculate A and \delta we have to calculate \omega.


    // w = sqrt(k/m) = sqrt(196/2) = 98 m/s
    // A = x/sin(w*t) = 0.1 / sin(98 *0) = 0
    // delta = tan(w*t) = tan(98 * 0) = 0

    typealias Solver = (Double, Double, Double, Double, Double) ->Void //defines typealias for a function that takes five Double arguments and returns nothing

// creation of structure that describes harmonic oscillator
struct HarmonicOscillator {
    var kSpring = 0.0
    var mass = 0.0
    var phase = 0.0
    var amplitude  = 0.0
    var deltaT = 0.0
    
    init(kSpring: Double, mass: Double, phase: Double, amplitude: Double, deltaT: Double) {
        self.kSpring = kSpring
        self.mass = mass
        self.phase = phase
        self.amplitude = amplitude
        self.deltaT = deltaT
    }
    
    func solveUsingSolver(solver: Solver) {
        solver(kSpring, mass, phase, amplitude, deltaT)
    }
    

    //: Euler Method
    
    // It is the simplest method for numerical integration. The idea behind this method is to approximate a curve by using short lines.
    //  This is done by calculating the slope on a given point and drawing a short line with the same slope. At the end of this line, you calculate the slope again and draw another line. As you can see, the accuracy depends on the length of the lines.
    func solveEuler(amplitude: Double, phase: Double, kSpring:Double, mass: Double, t:Double){
        var x = amplitude * sin(phase)
        let omega = sqrt(kSpring/mass)
        var i = 0.0
        
        var v = amplitude * omega * cos(phase)
        var vold = v
        var xoldEuler = x
        
        while i<100 {
            v -= omega * omega * x * t
            
            x += vold * t
             xoldEuler = x
            
            vold = v
            i+=t
            
        }
    }
    
    
    //: Velocity Verlet
    
    func solveVerlet(amplitude: Double, phase: Double, kSpring: Double, mass: Double, t: Double) {
        var x = amplitude * sin(phase)
        var xoldVerlet = x
        
        let omega = sqrt(kSpring/mass)
        
        var v = amplitude * omega * cos(phase)
        var vold = v
        var i = 0.0
        
        while i<100 {
            x = xoldVerlet + v * t + 0.5 * omega * omega * t * t
            v -= omega * omega * x * t
            xoldVerlet = x
            i += t
            
        }
        
        
    }
    
    func solveExact(kSpring: Double, mass: Double, phase: Double, amplitude: Double, t: Double){
        
        var x = 0.0
        
        let omega = sqrt(kSpring/mass)
        
        var i = 0.0
        
        while i<100.0 {
            x = amplitude * sin(omega * i + phase)
            i += t
        }
    }

    
}

let osci = HarmonicOscillator(kSpring: 0.5, mass: 10, phase: 10, amplitude: 50, deltaT: 0.1)

osci.solveExact(kSpring: 0.5, mass: 10, phase: 10, amplitude: 50, t: 0.1)


//solving Euler Method
osci.solveEuler(amplitude: 50, phase: 10, kSpring: 0.5, mass: 10, t: 0.1)
// solving Verlet method 

osci.solveVerlet(amplitude: 50, phase: 10, kSpring: 0.5, mass: 10, t: 0.1)









